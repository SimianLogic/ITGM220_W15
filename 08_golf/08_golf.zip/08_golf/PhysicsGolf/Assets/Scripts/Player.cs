﻿using UnityEngine;
using System.Collections;

//NOTE THAT PLAYER IS NOT A MONOBEHAVIOUR -- It's just a static data holder
public class Player
{

	public static float level = 0;
	public static float shotsTaken = 0;

}
